<?php
require('./php/session.php');
$q = $_REQUEST['q'];

$day = $_SESSION['getDay'];
echo $day;


?>