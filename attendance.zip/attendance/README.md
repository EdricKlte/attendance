font-family: "Roboto", sans-serif; <br>
Color: #78a861 and #e1b460 <br>
require_once $_SERVER['DOCUMENT_ROOT']."/attendance/database/connect.php";

